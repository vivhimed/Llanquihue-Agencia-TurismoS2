/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import model.Agencia;
import model.Tours;


/**
 *
 * @author Vivi
 */
public class CargarTours {
     
     public static void cargar(Agencia agen,String arch){
        FileReader fr;
        BufferedReader br;
        
        try{
            fr= new FileReader(arch);
            br= new BufferedReader(fr);
            String linea= br.readLine();
            while(linea!=null){
                if (!linea.trim().isEmpty()) {
                String cod= linea.substring(0,6);             
                Tours p= new Tours(linea);
                agen.agregar(cod, p);
                }
                linea= br.readLine();
            }
            br.close();
            fr.close();
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
           
    }
}


