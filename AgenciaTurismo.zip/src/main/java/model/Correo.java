/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;



import java.time.LocalDate;



/**
 *
 * @author Vivi
 */
public class Correo {
    
    private String remite;
    private LocalDate fecha; 
    private String glosa;
    
    
     /**
     * Constructor por defecto
     */
    public Correo(){
        this.remite=null;
        this.fecha=null;
        this.glosa=null;
    }

    public String getRemite() {
        return remite;
    }

    public void setRemite(String remite) {
        this.remite = remite;
    }
    
    // Devuelve la fecha convertida a texto (ej: "2026-11-22")
public String getFecha() {
    return this.fecha.toString();
}

    
// Recibe un texto (ej: "2026-11-22") y lo guarda como LocalDate en el atributo
public void setFecha(String fecha) {
    this.fecha = LocalDate.parse(fecha);
}
   

    public String getGlosa() {
        return glosa;
    }

    public void setGlosa(String glosa) {
        this.glosa = glosa;
    }
    
    public Correo(String remit, LocalDate fecha, String glosa) {
    this.remite = remit;
    this.fecha = fecha;
    this.glosa = glosa;
}
   public Correo(String remit, String fecha, String glosa) {
    this.remite = remit;
    this.fecha = LocalDate.parse(fecha); // Convierte el String a LocalDate
    this.glosa = glosa;
}
    
     /**
     * Constructor recibe objeto correo,  
     * valores separados por coma.
     * @param tours 
     */
//   
   public Correo(String linea) {
    String[] datos = linea.split(";");
    this.remite = datos[0].trim();
    this.fecha = LocalDate.parse(datos[1].trim());
    this.glosa = datos[2].trim();
}
    
    
    
//    public Correo(String linea){
//        String[] datos= correo.split(";");
//        this.remite=datos[0];
//        //this.fecha=fecha[1];
//        this.fecha = LocalDate.parse(datos[1];
//       //this.fecha = LocalDate.parse(datos[1].trim());
//        this.glosa=datos[2];
//    }  
    
    /**
     * Constructor de copia
     */
    public Correo(Correo e){
        this.remite=e.remite;
        this.fecha=e.fecha;
        this.glosa=e.glosa;
    }

      /**
     * Metodo toString()
     * Devuelve el objeto modo String atributo separados por comas.
     */
    @Override
    public String toString(){
        StringBuilder s= new StringBuilder();
        s.append(this.remite);
        s.append(";");
        s.append(this.fecha);
        s.append(";");
        s.append(this.glosa); 
                
        return s.toString();
    }
    
    
    public String mostrarInfo(){
        StringBuilder s= new StringBuilder();
        s.append("Remitente: ");        
        s.append(this.remite);
        s.append(" - ");
        s.append("Fecha: ");  
        s.append(this.fecha);
        s.append(" - ");
        s.append("glosa: ");  
        s.append(this.glosa); 
                
        return s.toString();
    
    }   
    
    
}