/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vivi
 */
public class Proveedor{
    private String  id;
    private String nombre;
    private String fono;
    private String correo;
    
    /**
     * Constructor por defecto
     */
    public Proveedor(){
        this.id= null;
        this.nombre=null;
        this.fono=null;
        this.correo=null;
    }
    
    /**
     * Constructor con parámetros 
     * @param id
     * @param nom
     * @param fono
     * @param correo
     */
    public Proveedor(String id, String nom, String fono, String correo){
        this.id= id;
        this.nombre=nom;
        this.fono=fono;
        this.correo=correo;
    }
    
     /**
     * Constructor recibe datos Proveedor  String 
     * en String los valores separados por comas
     * @param proveedor 
     */
    
    
    
    public Proveedor(String linea){       
        String[] datos= linea.split(";");
        this.id= datos[0];
        this.nombre=datos[1];
        this.fono=datos[2];
        this.correo=datos[3];
    }
//    public Proveedor(String proveedor){       
//        String[] datos= proveedor.split(",");
//        this.id= datos[0];
//        this.nombre=datos[1];
//        this.fono=datos[2];
//        this.correo=datos[3];
//    }
    /**
     * Getters & Setters
     * @return 
     */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFono() {
        return fono;
    }

    public void setFono(String fono) {
        this.fono = fono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    /**
     * Constructor de copia
     * @param e 
     */
       
    public Proveedor(Proveedor e){
        this.id= e.id;
        this.nombre=e.nombre;
        this.fono=e.fono;
        this.correo=e.correo;
    }

    
    /**
     * 
     *  devuelve una cadena con el ID, nombre, teléfono y correo separados por comas
     * @Override: Indica que estás sobrescribiendo el método toString()
     */
    @Override
    public String toString(){
        return this.id+","
                + this.nombre+","
                + this.fono + ","
                + this.correo;
    }
    
    public String mostrarInfo(){
        StringBuilder s= new StringBuilder();
        s.append("\n");
        s.append("Proveedor: ");
        s.append(this.id);
        s.append("\tNombre: ");
        s.append(this.nombre);
        s.append("\tCorreo: ");
        s.append(this.correo);
        return s.toString();
    }

    
}
