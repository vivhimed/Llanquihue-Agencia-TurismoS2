/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.ArrayList;
/**
 *
 * @author Vivi
 */
public class Agencia {
    
    private String nombre;
    private List<Proveedor> proveedores;
    private Stack<Correo> mails;
    private Map<String, Tours> tours;
    /**
 *  * Constructor por defecto de la clase Agencia.
 *  * Crea una instancia inicializando el nombre con un valor predeterminado ("NN")
 *  * e instancia las colecciones vacías para proveedores, correos y tours.
 *  */
    public Agencia(){
       this.nombre="NN";
       this.proveedores=new ArrayList<>();
       this.mails=new Stack<>();
       this.tours=new HashMap<>();       
    }
    
    /**
     * Este método es el constructor de la clase Agencia.
     * @param nombre 
     * Su función es crear e inicializar un nuevo objeto de este tipo en memoria.
     * Recibe una cadena de texto (String nombre) que se asigna
     * directamente al atributo interno de la clase.
     * Instancia las colecciones necesarias para evitar errores de referencia nula
     * (NullPointerException) al usar el objeto posteriormente:•
     * proveedores: Se inicializa como una lista dinámica vacía (ArrayList).
     * mails: Se inicializa como una pila vacía (Stack), ideal para gestionar
     * los correos bajo una lógica LIFO (último entra, primero sale).
     * tours: Se inicializa como un mapa clave-valor vacío (HashMap)
     * para almacenar y buscar los tours de forma eficiente.
     */
    
    public Agencia(String nombre){
        this.nombre=nombre;
        this.proveedores=new ArrayList<>();
        this.mails=new Stack<>();
        this.tours=new HashMap<>();
      
    }
       

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public List<Proveedor> getProveedores() {
        return proveedores;
    }
    public void setProveedores(List<Proveedor> proveedores) {
        this.proveedores = proveedores;
    }
    public Stack<Correo> getMails() {
        return mails;
    }
    public void setMails(Stack<Correo> mails) {
        this.mails = mails;
    }
    public Map<String, Tours> getTours() {
        return tours;
    }
    public void setTours(HashMap<String, Tours> tours) {
        this.tours = tours;
    }
    
    
    @Override
    public String toString(){
        return this.nombre;
    }   
    public String toStringProveedores(){
        return this.proveedores.toString();       
    }
    public String toStringCorreos(){
        return this.mails.toString();
    }
    public String toStringTours(){
        return this.tours.toString();
    }
  
    public String mostrarInfo(){
        StringBuilder s= new StringBuilder();
        s.append("\n");  
        s.append(" *===Agencia de Turismo ");
        s.append(this.nombre);
        s.append("===* ");
        s.append("\n\n");
        s.append(this.mostrarProveedores());
        s.append(this.mostrarCorreos());
        s.append(this.mostrarTours());
         
        return s.toString();
    } 
    
    /**
    * Genera listado formateado de información de todos los proveedores registrados.
    * Recorre la lista interna de proveedores y concatena sus representaciones en texto.
    * @return Una cadena de texto (String) con el encabezado y los detalles de cada proveedor.
    */
    
    public String mostrarProveedores(){
        StringBuilder s= new StringBuilder();
        s.append("\n");  
        s.append("===*Lista de Proveedores*===\n");
        int tope= this.proveedores.size();
        int i=0;
        while(i<tope){
            Proveedor p=this.proveedores.get(i);
            s.append(p.toString());
            s.append("\n");
            i++;
        }
        return s.toString();
        
    }      
    
    
    
    public String mostrarCorreos(){
        StringBuilder s= new StringBuilder();
        s.append("\n");  
        s.append("===* Lista de Correos *===\n");
        Stack<Correo> aux=new Stack<>();
        Correo correo;
        while (!this.mails.empty()){
           correo=this.mails.pop();
           s.append(correo.toString());
           s.append("\n");
           aux.push(correo);
        }
        //Restauramos Stack
        while(!aux.empty()){
            correo= aux.pop();
            this.mails.push(correo);
        }
        return s.toString();
    }    
    
    public String mostrarTours(){
        StringBuilder s= new StringBuilder();
        s.append("\n");  
        s.append("===* Lista de Tours *===\n");
        for (String clave: this.tours.keySet()){
            Tours p= this.tours.get(clave);
            s.append("--");
            s.append(p.toString());
            s.append("\n"); 
        }
         s.append("\n"); 
         return s.toString();
    }
    
    /**
    * Agrega un nuevo proveedor a la lista de proveedores de la agencia.
    * @param p El objeto de tipo Proveedor que se desea añadir.
    * @return {@code true} si el proveedor fue agregado correctamente a la lista.
    */
    
    public boolean agregar(Proveedor p){
        return this.proveedores.add(p);
       }
    
    /**
    * Añade un nuevo correo a la cima de la pila de mensajes de la agencia.
    * Sigue una estructura LIFO (el último correo agregado será el primero en procesarse).
    * @param c El objeto de tipo Correo que se desea apilar.
    */
public void agregar(Correo c) {
    this.mails.push(c);
}
  
    /**
     * Registra un nuevo tour en el mapa de la agencia asociándolo a un código único.
     * Si el código ya existe, reemplaza el tour anterior con el nuevo.
     * @param cod El código identificador único del tour (clave).
     * @param p   El objeto de tipo Tours que se desea almacenar (valor).
     */
    public void agregar(String cod, Tours p){
        this.tours.put(cod,p);
    }
   /**
    * Busca un proveedor en la lista de la agencia mediante su identificador único.
    * @param id El identificador (ID) del proveedor que se desea buscar.
    * @return El objeto {@code Proveedor} si se encuentra una coincidencia, 
    * retorna {@code null} si no existe ningún proveedor con ese ID.
 */ 
       
  public Proveedor buscarProveedor(String id) {
    for (Proveedor p : this.proveedores) {
        if (id.equals(p.getId())) {
            return p;
           }
    }
    return null;
    } 
 /**
 * Uso de Stack: Busca y recopila todos los correos enviados por un remitente específico.
 * Opera sobre una copia de la pila para preservar intactos los correos originales.
 * @param remite El nombre o dirección del remitente a buscar (no distingue mayúsculas).
 * @return Una cadena de texto (String) con la información de los correos encontrados,
 *         o una cadena vacía si no hubo coincidencias.
 */
    
    public String buscarCorreos(String remite) {
    StringBuilder s = new StringBuilder();
    Stack<Correo> clon = (Stack<Correo>) this.mails.clone();
    Correo actual; // <-- Nombre distinto al atributo de la clase

    while (!clon.empty()) {
        actual = clon.pop();
        if (remite.equalsIgnoreCase(actual.getRemite())) {
            s.append(actual.toString());
            s.append("\n");
        }
    }
    return s.toString();
}  
     /**
    * Busca y obtiene un tour registrado en el mapa de la agencia a partir de su clave.
    * @param clave El código o identificador único del tour que se desea consultar.
    * @return El objeto {@code Tours} asociado a la clave, o {@code null} si no existe.
    */
    public Tours buscarTour(String codigo) { // O puede devolver String si retorna datos formateados
    return this.tours.get(codigo);
}
//    public Tours buscarTours(String clave){
//        return this.tours.get(clave);
//        }
    
    
    public boolean eliminarUltimoCorreo() {
    if (!this.mails.isEmpty()) {
        this.mails.pop();
        return true;
    }
    return false;
}
    
  /**
    * Elimina un proveedor de la lista de la agencia según su identificador.
    * @param id El identificador (ID) del proveedor que se desea eliminar.
    * @return {@code true} si el proveedor fue encontrado y eliminado, 
    *         {@code false} si no existía ningún proveedor con ese ID.
  */
    
   public boolean eliminarProveedor(String id) {
    Proveedor p = this.buscarProveedor(id);
    if (p != null) {
        return this.proveedores.remove(p);
    }
    return false;
}
   
  /**
 * Elimina un tour del mapa de la agencia utilizando su clave única.
 * @param clave El código o identificador único del tour que se desea eliminar.
 * @return {@code true} si el tour existía y fue eliminado correctamente, 
 * {@code false} si no se encontró ningún tour con esa clave.
 */ 
   
   public boolean eliminarTour(String clave) {
    return this.tours.remove(clave) != null;
}
    
}

    

