/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Vivi
 */
public class Tours {
    
    private int codigo;
    private String nombre; 
    private int stock;
    
    
     /**
     * Constructor por defecto
     */
    public Tours(){
        this.codigo=0;
        this.nombre=null;
        this.stock=0;
    }
    /**
     * Constructor con parámetros.
     * @param cod
     * @param nom
     * @param stock 
     */
    public Tours(int cod, String nom, int stock){
        this.codigo=cod;
        this.nombre=nom;
        this.stock=stock;
    }
    
    /**
     * Constructor recibe objeto Tours,  
     * valores separados por coma.
     * @param tours 
     */
    public Tours(String tours){
        String[] datos= tours.split(";");
        this.codigo=Integer.parseInt(datos[0]);
        this.nombre=datos[1];
        this.stock=Integer.parseInt(datos[2]);
    }  
    
    /**
     * Constructor de copia
     */
    public Tours(Tours e){
        this.codigo=e.codigo;
        this.nombre=e.nombre;
        this.stock=e.stock;
    }

    /**
     * Getters & Setters
    */    
       
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
      
    /**
     * Metodo toString()
     * Devuelve el objeto modo String atributo separados por comas.
     */
    @Override
    public String toString(){
        StringBuilder s= new StringBuilder();
        s.append(this.codigo);
        s.append(";");
        s.append(this.nombre);
        s.append(";");
        s.append(this.stock); 
                
        return s.toString();
    }
    
    
    public String mostrarInfo(){
        StringBuilder s= new StringBuilder();
        s.append("Codigo: ");        
        s.append(this.codigo);
        s.append(" - ");
        s.append("Tours: ");  
        s.append(this.nombre);
        s.append(" - ");
        s.append("Cupos: ");  
        s.append(this.stock); 
                
        return s.toString();
    } 
   


}
