/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;
import data.CargarCorreos;
import data.CargarTours;
import data.CargarProveedores;
import java.time.LocalDate;
import java.util.Scanner;
import model.Agencia;
import model.Proveedor;
import model.Tours;
import model.Correo;


/**
 *
 * @author Vivi
 */
public class Main {

        public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        
        Agencia agen= new Agencia("Florencia Spa.");
        CargarCorreos.cargar(agen,  "src/main/resources/correos.txt");
        CargarProveedores.cargar(agen, "src/main/resources/proveedores.txt");
        CargarTours.cargar(agen, "src/main/resources/tours.txt");
        
        System.out.println(agen.mostrarInfo());
        
        //Agregar nuevos datos a las colecciones
        
        Correo mail= new Correo("yo@mail.com",LocalDate.now(),
                                "Proceso de importación N°12.345, terminado exitosamente");
        Correo correo= new Correo("Evaristo@hoteltito.com",LocalDate.now(),"Reserva por 3 dias 5 personas");
        Proveedor prov=new Proveedor("23243","Hostal Carmen","(+56)935557234", "contacto@hostalcarmen.com");
        Tours tur= new Tours(63864,"Arboleda Rapel",15);
        
        
        agen.agregar(correo);
        agen.agregar(prov);
        agen.agregar("28674", tur);
        
        System.out.println(agen.mostrarInfo());
        
        //Búsquedas
              
        String clave= "676786";
        Tours p= agen.buscarTour(clave);
        System.out.println("\nTours clave: :"+ clave + "->" + p.mostrarInfo());
        
        clave= "998764";
        p= agen.buscarTour(clave);
        if (p!= null){
            System.out.println("\nTours clave: " + clave +" -> "+p.mostrarInfo());
        }
        else{
            System.out.println("\nTours clave: "+ clave+ "  no registrado");
        }

       
        
    }
}

